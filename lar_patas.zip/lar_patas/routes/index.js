const express = require('express');
const UsuarioController = require('../controllers/UsuarioController');
const AnimalController = require('../controllers/AnimalController');
const PessoaController = require('../controllers/PessoaController');
const AdocaoController = require('../controllers/AdocaoController');
const DimPessoaController = require('../controllers/DimPessoaController');

const auth = require('../middlewares/auth');

const routes = express.Router();

// Login
routes.post('/login', UsuarioController.login);

// Usuários
routes.get('/usuarios', auth, UsuarioController.index);
routes.post('/usuarios', UsuarioController.create);
routes.delete('/usuarios/:id', auth, UsuarioController.delete);

// Animais
routes.get('/animais', auth, AnimalController.index);
routes.get('/animais/:id', auth, AnimalController.show);
routes.post('/animais', auth, AnimalController.create);
routes.put('/animais/:id', auth, AnimalController.update);
routes.delete('/animais/:id', auth, AnimalController.delete);

// Pessoas
routes.get('/pessoas', auth, PessoaController.index);
routes.get('/pessoas/:id', auth, PessoaController.show);
routes.post('/pessoas', PessoaController.create);
routes.put('/pessoas/:id', auth, PessoaController.update);
routes.delete('/pessoas/:id', auth, PessoaController.delete);

// Adoções
routes.get('/adocoes', auth, AdocaoController.index);
routes.get('/adocoes/:id', auth, AdocaoController.show);
routes.post('/adocoes', auth, AdocaoController.create);
routes.put('/adocoes/:id', auth, AdocaoController.update);
routes.delete('/adocoes/:id', auth, AdocaoController.delete);

// Dimensão Pessoa (somente leitura)
routes.get('/dim_pessoas', auth, DimPessoaController.index);
routes.get('/dim_pessoas/:id', auth, DimPessoaController.show);

module.exports = routes;
