const db = require('../database/connection');

module.exports = {
  async index(req, res) {
    const adocoes = await db('adocoes');
    return res.json(adocoes);
  },

  async show(req, res) {
    const { id } = req.params;
    const adocao = await db('adocoes').where({ id }).first();

    if (!adocao) return res.status(404).json({ error: 'Adoção não encontrada' });

    return res.json(adocao);
  },

  async create(req, res) {
    const data = req.body;

    const [id] = await db('adocoes').insert(data);

    return res.json({ id });
  },

  async update(req, res) {
    const { id } = req.params;
    const data = req.body;

    await db('adocoes').where({ id }).update(data);

    return res.status(204).send();
  },

  async delete(req, res) {
    const { id } = req.params;

    await db('adocoes').where({ id }).del();

    return res.status(204).send();
  }
};
