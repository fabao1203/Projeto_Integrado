const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const db = require('../database/connection');

module.exports = {
  // Login
  async login(req, res) {
    try {
      const { usuario, senha } = req.body;

      if (!usuario || !senha) {
        return res.status(400).json({ error: 'Usuário e senha são obrigatórios' });
      }

      // Busca o usuário pelo login (campo 'login' na tabela)
      const user = await db('usuarios').where('login', usuario).first();

      if (!user) {
        return res.status(401).json({ error: 'Usuário não encontrado' });
      }

      // Verifica senha com bcrypt
      const senhaValida = await bcrypt.compare(senha, user.senha);
      if (!senhaValida) {
        return res.status(401).json({ error: 'Senha incorreta' });
      }

      // Gera token JWT (exemplo básico)
      const token = jwt.sign(
        { id: user.id, login: user.login, nivel_acesso: user.nivel_acesso },
        'seuSegredoSuperSecreto', // coloque em variável ambiente
        { expiresIn: '1h' }
      );

      return res.json({ token });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Erro interno' });
    }
  },

  // Listar usuários
  async index(req, res) {
    try {
      const usuarios = await db('usuarios')
        .join('pessoas', 'usuarios.pessoa_id', '=', 'pessoas.id')
        .select(
          'usuarios.id',
          'usuarios.login',
          'usuarios.nivel_acesso',
          'usuarios.ativo',
          'pessoas.nome',
          'pessoas.email'
        );

      return res.json(usuarios);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Erro ao listar usuários' });
    }
  },

  // Criar usuário
  async create(req, res) {
    const { pessoa_id, login, senha, nivel_acesso, ativo } = req.body;

    try {
      const hash = await bcrypt.hash(senha, 10);

      const [id] = await db('usuarios').insert({
        pessoa_id,
        login,
        senha: hash,
        nivel_acesso,
        ativo
      });

      return res.status(201).json({ id });
    } catch (error) {
      console.error(error);
      return res.status(400).json({ error: 'Erro ao criar usuário.' });
    }
  },

  // Deletar usuário
  async delete(req, res) {
    const { id } = req.params;

    try {
      await db('usuarios').where({ id }).del();
      return res.status(204).send();
    } catch (error) {
      console.error(error);
      return res.status(400).json({ error: 'Erro ao deletar usuário.' });
    }
  }
};
