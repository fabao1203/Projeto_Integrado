const db = require('../database/connection');

module.exports = {
  async index(req, res) {
    const pessoas = await db('dim_pessoa');
    return res.json(pessoas);
  },

  async show(req, res) {
    const { id } = req.params;
    const pessoa = await db('dim_pessoa').where({ id }).first();

    if (!pessoa) return res.status(404).json({ error: 'Dimensão pessoa não encontrada' });

    return res.json(pessoa);
  }
};
