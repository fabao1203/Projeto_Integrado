const db = require('../database/connection');

module.exports = {
  async index(req, res) {
    const animais = await db('animais');
    return res.json(animais);
  },

  async show(req, res) {
    const { id } = req.params;
    const animal = await db('animais').where({ id }).first();

    if (!animal) return res.status(404).json({ error: 'Animal não encontrado' });

    return res.json(animal);
  },

  async create(req, res) {
    const data = req.body;

    const [id] = await db('animais').insert(data);

    return res.json({ id });
  },

  async update(req, res) {
    const { id } = req.params;
    const data = req.body;

    await db('animais').where({ id }).update(data);

    return res.status(204).send();
  },

  async delete(req, res) {
    const { id } = req.params;

    await db('animais').where({ id }).del();

    return res.status(204).send();
  }
};
