const db = require('../database/connection');

module.exports = {
  async index(req, res) {
    const pessoas = await db('pessoas');
    return res.json(pessoas);
  },

  async show(req, res) {
    const { id } = req.params;
    const pessoa = await db('pessoas').where({ id }).first();

    if (!pessoa) return res.status(404).json({ error: 'Pessoa não encontrada' });

    return res.json(pessoa);
  },

  async create(req, res) {
    const data = req.body;

    const [id] = await db('pessoas').insert(data);

    return res.json({ id });
  },

  async update(req, res) {
    const { id } = req.params;
    const data = req.body;

    await db('pessoas').where({ id }).update(data);

    return res.status(204).send();
  },

  async delete(req, res) {
    const { id } = req.params;

    await db('pessoas').where({ id }).del();

    return res.status(204).send();
  }
};
