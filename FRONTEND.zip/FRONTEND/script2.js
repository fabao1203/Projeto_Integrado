
// Dados dos pets
const pets = [
    // Cachorros (5)
    {
      id: 1,
      nome: "Rex",
      tipo: "Cachorro",
      idade: "2 anos",
      descricao: "Brincalhão e adora crianças!",
      iconClass: "dog"
    },
    {
      id: 2,
      nome: "Thor",
      tipo: "Cachorro",
      idade: "3 anos",
      descricao: "Protetor e muito leal.",
      iconClass: "dog"
    },
    {
      id: 3,
      nome: "Luna",
      tipo: "Cachorro",
      idade: "1 ano",
      descricao: "Energética e carinhosa.",
      iconClass: "dog"
    },
    {
      id: 4,
      nome: "Bobby",
      tipo: "Cachorro",
      idade: "4 anos",
      descricao: "Calmo e ama passear.",
      iconClass: "dog"
    },
    {
      id: 5,
      nome: "Zoe",
      tipo: "Cachorro",
      idade: "5 meses",
      descricao: "Filhote curiosa e divertida.",
      iconClass: "dog"
    },
  
    // Gatos (3)
    {
      id: 6,
      nome: "Mimi",
      tipo: "Gato",
      idade: "1 ano",
      descricao: "Calmo e carinhoso.",
      iconClass: "cat"
    },
    {
      id: 7,
      nome: "Oliver",
      tipo: "Gato",
      idade: "2 anos",
      descricao: "Independente e brincalhão.",
      iconClass: "cat"
    },
    {
      id: 8,
      nome: "Bella",
      tipo: "Gato",
      idade: "3 anos",
      descricao: "Ama sonecas ao sol.",
      iconClass: "cat"
    },
  
    // Répteis (2)
    {
      id: 9,
      nome: "Ziggy",
      tipo: "Réptil",
      idade: "3 anos",
      descricao: "Iguana tranquila e dócil.",
      iconClass: "reptile"
    },
    {
      id: 10,
      nome: "Rango",
      tipo: "Réptil",
      idade: "1 ano",
      descricao: "Camaleão que adora insetos.",
      iconClass: "reptile"
    },
  
    // Aves (4)
    {
      id: 11,
      nome: "Piu",
      tipo: "Pássaro",
      idade: "6 meses",
      descricao: "Canta lindamente pela manhã.",
      iconClass: "bird"
    },
    {
      id: 12,
      nome: "Loro",
      tipo: "Pássaro",
      idade: "2 anos",
      descricao: "Papagaio que imita vozes.",
      iconClass: "bird"
    },
    {
      id: 13,
      nome: "Twitty",
      tipo: "Pássaro",
      idade: "1 ano",
      descricao: "Canário de cor vibrante.",
      iconClass: "bird"
    },
    {
      id: 14,
      nome: "Blue",
      tipo: "Pássaro",
      idade: "3 anos",
      descricao: "Calopsita sociável.",
      iconClass: "bird"
    }
  ];
  
  // Mapeamento de ícones (Font Awesome)

  
  // Renderiza os pets na tela
  function renderPets(petsToRender = pets) {
    const petList = document.getElementById('petList');
    petList.innerHTML = '';
  
    petsToRender.forEach(pet => {
      const card = `
        <div class="pet-card">
          <div class="pet-icon ${pet.iconClass}">
            <i class="fas ${{
              dog: "fa-dog",
              cat: "fa-cat",
              bird: "fa-dove",
              reptile: "fa-dragon"
          }[pet.iconClass]}"></i>
          </div>
          <div class="pet-info">
            <h3>${pet.nome}</h3>
            <p><strong>Tipo:</strong> ${pet.tipo}</p>
            <p><strong>Idade:</strong> ${pet.idade}</p>
            <p>${pet.descricao}</p>
            <button class="adopt-button" onclick="alert('Formulário de adoção para ${pet.nome} será aberto!')">
              Quero Adotar
            </button>
          </div>
        </div>
      `;
      petList.innerHTML += card;
    });
  }
  
  // Filtra pets por tipo/nome
  document.querySelector('.search-bar button').addEventListener('click', () => {
    const termo = document.querySelector('.search-bar input').value.toLowerCase();
    const petsFiltrados = pets.filter(pet => 
      pet.tipo.toLowerCase().includes(termo) || 
      pet.nome.toLowerCase().includes(termo)
    );
    renderPets(petsFiltrados);
  });
  
  // Inicializa a página
  renderPets();

  
  // Mapeamento de ícones (Font Awesome)
  const icons = {
    dog: "fa-dog",
    cat: "fa-cat",
    bird: "fa-dove",
    rodent: "fa-bunny",  
    reptile: "fa-dragon"   
  };
  
  // Renderiza os pets na tela
  function renderPets(petsToRender = pets) {
    const petList = document.getElementById('petList');
    petList.innerHTML = '';
  
    petsToRender.forEach(pet => {
      const card = `
        <div class="pet-card">
          <div class="pet-icon ${pet.iconClass}">
            <i class="fas ${{
              dog: "fa-dog",
              cat: "fa-cat",
              bird: "fa-dove",
              reptile: "fa-dragon"
          }[pet.iconClass]}"></i>
          </div>
          <div class="pet-info">
            <h3>${pet.nome}</h3>
            <p><strong>Tipo:</strong> ${pet.tipo}</p>
            <p><strong>Idade:</strong> ${pet.idade}</p>
            <p>${pet.descricao}</p>
            <button class="adopt-button" onclick="alert('Formulário de adoção para ${pet.nome} será aberto!')">
              Quero Adotar
            </button>
          </div>
        </div>
      `;
      petList.innerHTML += card;
    });
  }
  
  // Filtra pets por tipo
  document.querySelector('.search-bar button').addEventListener('click', () => {
    const termo = document.querySelector('.search-bar input').value.toLowerCase();
    const petsFiltrados = pets.filter(pet => 
      pet.tipo.toLowerCase().includes(termo) || 
      pet.nome.toLowerCase().includes(termo)
    );
    renderPets(petsFiltrados);
  });
  // Função de login
async function login(email, password) {
  try {
    const userCredential = await firebase.auth().signInWithEmailAndPassword(email, password);
    // Redireciona se o login for bem-sucedido
    window.location.href = "admin.html";
  } catch (error) {
    // Trata erros
    let errorMessage = "Erro ao fazer login: ";
    switch(error.code) {
      case "auth/user-not-found":
        errorMessage += "Usuário não cadastrado";
        break;
      case "auth/wrong-password":
        errorMessage += "Senha incorreta";
        break;
      default:
        errorMessage += error.message;
    }
    alert(errorMessage);
  }
}

// Evento de submit do formulário
document.getElementById("loginForm").addEventListener("submit", (e) => {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  login(email, password);
});
// script2.js - Atualizado para usar Firebase

// Função para renderizar pets
async function renderPets(petsToRender = null) {
  const petList = document.getElementById('petList');
  petList.innerHTML = '';

  // Se não receber uma lista específica, busca do Firebase
  const pets = petsToRender || await getPetsFromFirebase();

  pets.forEach(pet => {
    const card = `
      <div class="pet-card pet-type-${pet.tipo.toLowerCase()}">
        <div class="pet-icon">
          <i class="fas ${getPetIcon(pet.tipo)}"></i>
        </div>
        <div class="pet-info">
          <h3>${pet.nome}</h3>
          <p><strong>Tipo:</strong> ${pet.tipo}</p>
          <p><strong>Idade:</strong> ${pet.idade}</p>
          <p>${pet.descricao}</p>
          <button class="adopt-button" onclick="openAdoptionForm('${pet.id}')">
            Quero Adotar
          </button>
        </div>
      </div>
    `;
    petList.innerHTML += card;
  });
}

// Busca pets do Firebase
async function getPetsFromFirebase() {
  try {
    const snapshot = await db.collection('pets')
      .where('disponivel', '==', true)
      .get();
    
    return snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
  } catch (error) {
    console.error("Erro ao buscar pets:", error);
    return [];
  }
}

// Filtra pets por tipo/nome
document.querySelector('.search-bar button').addEventListener('click', async () => {
  const termo = document.querySelector('.search-bar input').value.toLowerCase();
  const pets = await getPetsFromFirebase();
  
  const petsFiltrados = pets.filter(pet => 
    pet.tipo.toLowerCase().includes(termo) || 
    pet.nome.toLowerCase().includes(termo)
  );
  
  renderPets(petsFiltrados);
});

// Função para abrir formulário de adoção
async function openAdoptionForm(petId) {
  // Verifica se o usuário está logado
  const user = auth.currentUser;
  if (!user) {
    alert('Por favor, faça login antes de adotar um pet.');
    window.location.href = 'login.html';
    return;
  }

  // Aqui você pode abrir um modal ou redirecionar para uma página de formulário
  const petDoc = await db.collection('pets').doc(petId).get();
  const pet = petDoc.data();
  
  // Exemplo simples com prompt
  const motivo = prompt(`Por que você quer adotar ${pet.nome}?`);
  if (motivo) {
    try {
      await db.collection('adocoes').add({
        petId,
        userId: user.uid,
        petName: pet.nome,
        userName: user.displayName || prompt('Por favor, digite seu nome completo:'),
        userEmail: user.email,
        motivo,
        status: 'pendente',
        createdAt: firebase.firestore.FieldValue.serverTimestamp()
      });
      
      alert(`Pedido de adoção para ${pet.nome} enviado com sucesso! Entraremos em contato em breve.`);
    } catch (error) {
      console.error("Erro ao solicitar adoção:", error);
      alert("Ocorreu um erro ao enviar sua solicitação. Por favor, tente novamente.");
    }
  }
}

// Inicializa a página
document.addEventListener('DOMContentLoaded', async () => {
  // Verifica autenticação
  auth.onAuthStateChanged(user => {
    if (user) {
      console.log("Usuário logado:", user.email);
    } else {
      console.log("Nenhum usuário logado");
    }
  });

  // Carrega os pets
  await renderPets();
});

  
  // Inicializa a página
  renderPets();


